package com.kale.activityoptions.anim;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.view.View;

import com.kale.activityoptions.transition.TransitionCompat.ViewAnimationListener;

public class ViewAnimationListenerAdapter implements ViewAnimationListener{

	@Override
	public void onInitAnimationViews(View view, int id) {
		// TODO 自动生成的方法存根
		
	}

	@Override
	public void onViewAnimationStart(View view, Animator animator) {
		// TODO 自动生成的方法存根
		
	}

	@Override
	public void onViewAnimationUpdate(View view, ValueAnimator valueAnimator,
			float progress) {
		// TODO 自动生成的方法存根
		
	}

	@Override
	public void onViewAnimationEnd(View view, Animator animator) {
		// TODO 自动生成的方法存根
		
	}

	@Override
	public void onViewAnimationCancel(View view, Animator animator) {
		// TODO 自动生成的方法存根
		
	}

}
