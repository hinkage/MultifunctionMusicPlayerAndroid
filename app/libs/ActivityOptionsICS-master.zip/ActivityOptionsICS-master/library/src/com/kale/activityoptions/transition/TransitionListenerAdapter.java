package com.kale.activityoptions.transition;

import android.animation.Animator;
import android.view.animation.Animation;

import com.kale.activityoptions.transition.TransitionCompat.TransitionListener;

public class TransitionListenerAdapter implements TransitionListener{

	@Override
	public void onTransitionStart(Animator animator, Animation animation,
			boolean isEnter) {
		// TODO 自动生成的方法存根
		
	}

	@Override
	public void onTransitionEnd(Animator animator, Animation animation,
			boolean isEnter) {
		// TODO 自动生成的方法存根
		
	}

	@Override
	public void onTransitionCancel(Animator animator, Animation animation,
			boolean isEnter) {
		// TODO 自动生成的方法存根
		
	}

	
	
}
